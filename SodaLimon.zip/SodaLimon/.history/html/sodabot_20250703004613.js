// PROBANDO CHATBOT

function toggleChat() {
  const chatBox = document.getElementById("chatBox");
  const isVisible = chatBox.style.display === "flex";
  chatBox.style.display = isVisible ? "none" : "flex";
  chatBox.style.flexDirection = "column";

  if (!isVisible) {
    hideNotification(); // Ocultar notificación al abrir chat
  }
}

function sendMessage() {
  const input = document.getElementById("userInput");
  const msg = input.value.trim();
  if (!msg) return;

  addMessage("user", msg);
  input.value = "";

  // Mostrar indicador de escritura
  showTypingIndicator();

  setTimeout(() => {
    generateBotResponse(msg);
    hideTypingIndicator();

    // Si el chat está cerrado, mostrar notificación
    const chatBox = document.getElementById("chatBox");
    if (chatBox.style.display === "none") {
      showNotification();
    }
  }, 4000); // tiempo simulado para "escribiendo..."
}

function addMessage(type, text) {
  const chatBody = document.getElementById("chatBody");
  const msgEl = document.createElement("div");
  msgEl.className = type + "-msg";
  msgEl.textContent = text;
  chatBody.insertBefore(msgEl, document.getElementById("typingIndicator")); // Añadir antes del indicador
  chatBody.scrollTop = chatBody.scrollHeight;
}

function generateBotResponse(userMsg) {
  const msg = userMsg.toLowerCase();
  let response = "";

  if (msg.includes("hola") || msg.includes("buenas")) {
    response = "¡Hola Sodero! ¿En qué puedo ayudarte hoy?";
  }
  if (msg.includes("productos")) {
    response = "Tenemos refrescos como RedSpark, BlueFizz y Limón Soul 🍋.";
  }
  if (msg.includes("contacto") || msg.includes("hablar")) {
    response = "Puedes contactarnos al correo: contacto@sodalimon.com 📧";
  }
  if (msg.includes("trabajo") || msg.includes("empleo")) {
    response = "Visita la sección 'Trabaja con nosotros' para ver oportunidades laborales.";
  }
  if (msg.includes("entrega") || msg.includes("delivery")) {
    response = "Sí, realizamos entregas a domicilio 🚚.";
  }
  if (msg.includes("horario")) {
    response = "Atendemos de lunes a sábado de 9:00 a.m. a 7:00 p.m. ⏰";
  }
  if (msg.includes("azucar") || msg.includes("sin azúcar")) {
    response = "Sí, tenemos bebidas sin azúcar 💚.";
  }
  if (msg.includes("pedido")) {
    response = "Puedes hacer tu pedido por WhatsApp, redes o nuestra web.";
  }
  if (msg.includes("ubicacion") || msg.includes("dónde están") || msg.includes("dirección")) {
    response = "Estamos en Ica, Perú 🇵🇪 y realizamos entregas a todo el país.";
  }
  if (msg.includes("agua vip")) {
    response = "Buena opción: una bebida para mantenerte 100% hidratado después de esta terrible calor en Ica. 🥵";
  }
  if (msg.includes("chiste") || msg.includes("gracioso")) {
    response = "¿Qué hace un perro con un taladro? ¡Ta-ladrando!. 😂";
  }

  if (!response) {
    response = "Lo siento, aún estoy aprendiendo. ¿Podrías intentar con otra pregunta?";
  }

  addMessage("bot", response);
}

function handleKey(event) {
  if (event.key === "Enter") {
    sendMessage();
  }
}

// Indicador de "escribiendo..."
function showTypingIndicator() {
  const indicator = document.getElementById("typingIndicator");
  if (indicator) {
    indicator.style.display = "block";
  }
}

function hideTypingIndicator() {
  const indicator = document.getElementById("typingIndicator");
  if (indicator) {
    indicator.style.display = "none";
  }
}

// Notificaciones visuales
function showNotification() {
  const dot = document.getElementById("notifDot");
  if (dot) {
    dot.style.display = "inline-block";
  }
}

function hideNotification() {
  const dot = document.getElementById("notifDot");
  if (dot) {
    dot.style.display = "none";
  }
}





document.getElementById('newsletterForm').addEventListener('submit', function(event) {
  event.preventDefault();

  const email = document.getElementById('emailInput').value.trim();
  const password = document.getElementById('passwordInput').value.trim();
  const phone = document.getElementById('phoneInput').value.trim();
  const formMessage = document.getElementById('formMessage');

  // Validaciones básicas
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phoneRegex = /^\+?\d{7,15}$/;  // permite números con + y entre 7 y 15 dígitos

  if (!emailRegex.test(email)) {
    formMessage.style.color = 'red';
    formMessage.textContent = 'Por favor ingresa un correo válido.';
    formMessage.style.display = 'block';
    return;
  }
  if (password.length < 6) {
    formMessage.style.color = 'red';
    formMessage.textContent = 'La contraseña debe tener al menos 6 caracteres.';
    formMessage.style.display = 'block';
    return;
  }
  if (!phoneRegex.test(phone)) {
    formMessage.style.color = 'red';
    formMessage.textContent = 'Por favor ingresa un número celular válido.';
    formMessage.style.display = 'block';
    return;
  }

  // Aquí iría el envío a backend o servicio

  // Mensaje personalizado
  formMessage.style.color = 'green';
  formMessage.textContent = '¡Estás subscrito, Sodero! Espera nuestras nuevas novedades.';
  formMessage.style.display = 'block';

  // Limpiar inputs
  document.getElementById('newsletterForm').reset();
});

