let numeroFactura = localStorage.getItem("numeroFactura") || 1;

function abrirFormulario() {
  document.getElementById("formularioModal").style.display = "block";
  if (!document.querySelector(".producto-item")) agregarProducto();
}

function agregarProducto() {
  const div = document.createElement("div");
  div.className = "producto-item";
  div.innerHTML = `
    <label>Descripción:</label>
    <input type="text" class="descripcion" required>
    <label>Cantidad:</label>
    <input type="number" class="cantidad" value="1" required>
    <label>Precio Unitario:</label>
    <input type="number" class="precio" value="0" required>
  `;
  document.getElementById("productos").appendChild(div);
}

document.getElementById("formFactura").addEventListener("submit", function(e) {
  e.preventDefault();

  const empresa = document.getElementById("empresa").value;
  const ruc = document.getElementById("ruc").value;
  const cliente = document.getElementById("cliente").value;
  const direccion = document.getElementById("direccion").value;
  const fecha = document.getElementById("fecha").value;

  document.getElementById("outNombreEmpresa").textContent = empresa.toUpperCase();
  document.getElementById("outEmpresa").textContent = empresa;
  document.getElementById("outRuc").textContent = ruc;
  document.getElementById("outCliente").textContent = cliente;
  document.getElementById("outDireccion").textContent = direccion;
  document.getElementById("outFecha").textContent = fecha;
  document.getElementById("outFacturaNumero").textContent = `F001-${String(numeroFactura).padStart(6, '0')}`;

  let subtotal = 0;
  const tabla = document.getElementById("tablaProductos");
  tabla.innerHTML = "";

  document.querySelectorAll(".producto-item").forEach(item => {
    const desc = item.querySelector(".descripcion").value;
    const cant = parseFloat(item.querySelector(".cantidad").value);
    const precio = parseFloat(item.querySelector(".precio").value);
    const importe = cant * precio;
    subtotal += importe;

    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${cant}</td>
      <td>${desc}</td>
      <td>S/ ${precio.toFixed(2)}</td>
      <td>S/ ${importe.toFixed(2)}</td>
    `;
    tabla.appendChild(row);
  });

  const igv = subtotal * 0.18;
  const total = subtotal + igv;

  document.getElementById("subtotal").textContent = `S/ ${subtotal.toFixed(2)}`;
  document.getElementById("igv").textContent = `S/ ${igv.toFixed(2)}`;
  document.getElementById("total").textContent = `S/ ${total.toFixed(2)}`;
  document.getElementById("totalLetras").textContent = numeroALetras(total.toFixed(2));

  localStorage.setItem("numeroFactura", ++numeroFactura);
  document.getElementById("factura").style.display = "block";
  document.getElementById("formularioModal").style.display = "none";
});

function descargarPDF() {
  const factura = document.getElementById("factura");

  // Asegurarse de que la factura esté contenida en un tamaño adecuado
  const options = {
    margin: 10, // Reduce los márgenes
    filename: 'factura.pdf', // Nombre del archivo PDF
    html2canvas: {
      scale: 2, // Mejora la calidad de la imagen
      logging: true, // Muestra en consola si hay errores
      useCORS: true // Usa CORS para imágenes externas
    },
    jsPDF: {
      unit: 'mm', 
      format: 'a4', // Ajusta el formato a A4
      orientation: 'portrait' // Ajusta la orientación de la página
    }
  };

  html2pdf().from(factura).set(options).save();
}

function numeroALetras(numero) {
  const unidades = ["", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve"];
  const decenas = ["", "diez", "veinte", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa"];
  const centenas = ["", "ciento", "doscientos", "trescientos", "cuatrocientos", "quinientos", "seiscientos", "setecientos", "ochocientos", "novecientos"];

  numero = parseFloat(numero).toFixed(2);
  const [entero, decimal] = numero.split(".");
  let letras = "";

  if (parseInt(entero) === 0) letras = "cero";
  else if (parseInt(entero) === 100) letras = "cien";
  else {
    const c = Math.floor(entero / 100);
    const d = Math.floor((entero % 100) / 10);
    const u = entero % 10;
    letras = `${centenas[c]} ${decenas[d]} ${unidades[u]}`;
  }

  return letras.trim().toUpperCase() + ` Y ${decimal}/100 SOLES`;
}
